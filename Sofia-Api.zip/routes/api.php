<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PassportController;
use App\Http\Controllers\ProductController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

//User Authentication Api's
Route::post('register', [PassportController::class, 'register']);
Route::post('login', [PassportController::class, 'login']);
Route::get('allusers', [PassportController::class, 'all_users']);
Route::post('update-user', [PassportController::class, 'update_user']);




///Products API's /////////
Route::post('insert-product', [ProductController::class, 'create_product']);
Route::get('get-products', [ProductController::class, 'allproducts']);
Route::post('single-product/{id}',[ProductController::class,'show_product']);
Route::post('delete-product/{id}',[ProductController::class,'destroy_product']);




// put all api protected routes here
Route::middleware('auth:api')->group(function () {
    Route::post('user-detail', [PassportController::class, 'userDetail']);
    Route::post('logout', [PassportController::class, 'logout']);
});